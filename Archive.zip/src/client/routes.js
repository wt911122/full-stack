import Index from './views/index.vue';
export default [
    { path: '/', component: Index },
    { path: '*', component: Index },
];
